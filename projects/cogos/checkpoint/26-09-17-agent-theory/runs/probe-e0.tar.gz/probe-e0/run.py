#!/usr/bin/env python3.11
"""E0 probe runner: send one frame to lm-service, snapshot request+response+meta.

Not agent code. Only does: load a request json, override temperature, repeat N
times, save snapshots, print a compact summary.

Usage:
  python3.11 run.py --request arms/lite/turn-003-request.json \
      --temp 0.8 --reps 3 --label t3-lite

Snapshots land in runs/<label>/<rep>/ : request.json, response.json, meta.json
"""
import argparse
import hashlib
import json
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
URL = "http://127.0.0.1:11434/v1/chat/completions"
KEY = "ik_c47WkfAw7E5v6Ck8idMHgg"


def sha(obj):
    return hashlib.sha256(
        json.dumps(obj, ensure_ascii=False, sort_keys=True).encode()
    ).hexdigest()[:16]


def call(body):
    req = urllib.request.Request(
        URL,
        data=json.dumps(body, ensure_ascii=False).encode(),
        headers={"X-Internal-Key": KEY, "Content-Type": "application/json"},
        method="POST",
    )
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read()), resp.status, time.time() - t0
    except urllib.error.HTTPError as e:
        return json.loads(e.read()), e.code, time.time() - t0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--request", required=True)
    ap.add_argument("--temp", type=float, default=0.0)
    ap.add_argument("--reps", type=int, default=1)
    ap.add_argument("--label", required=True)
    ap.add_argument("--thinking", action="store_true")
    args = ap.parse_args()

    src = (HERE / args.request).resolve()
    base = json.loads(src.read_text())
    prefix = base["messages"][:-1]
    last = base["messages"][-1]["content"] if base["messages"] else ""

    outdir = HERE / "runs" / args.label
    outdir.mkdir(parents=True, exist_ok=True)

    print(f"label={args.label} temp={args.temp} reps={args.reps}")
    print(f"prefix_hash={sha(prefix)}  last_msg_hash={sha(last)}")
    for r in range(args.reps):
        body = dict(base)
        body["temperature"] = args.temp
        body["thinking"] = {"enabled": bool(args.thinking)}
        raw, status, dt = call(body)
        repdir = outdir / f"r{r}"
        repdir.mkdir(parents=True, exist_ok=True)
        (repdir / "request.json").write_text(
            json.dumps(body, ensure_ascii=False, indent=2)
        )
        (repdir / "response.json").write_text(
            json.dumps(raw, ensure_ascii=False, indent=2)
        )
        (repdir / "meta.json").write_text(
            json.dumps(
                {
                    "label": args.label,
                    "source_request": str(src.relative_to(HERE)),
                    "temperature": args.temp,
                    "thinking": bool(args.thinking),
                    "rep": r,
                    "status": status,
                    "seconds": round(dt, 2),
                    "prefix_hash": sha(prefix),
                    "last_msg_hash": sha(last),
                    "usage": raw.get("usage"),
                    "finish_reason": raw.get("finish_reason"),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        fr = raw.get("finish_reason")
        content = "".join(p.get("text", "") for p in raw.get("content") or [])
        tcalls = raw.get("tool_calls") or []
        spoke = ", ".join(
            f'{t["name"]}->{t["args"].get("to")}' for t in tcalls
        ) or "-"
        flag = ("想" if content.strip() else "") + ("说" if tcalls else "")
        print(f"  r{r}: {fr:10s} [{flag or '静默':4s}] said={spoke} "
              f"think_len={len(content)} {dt:.1f}s")


if __name__ == "__main__":
    main()
