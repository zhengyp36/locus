#!/usr/bin/env python3.11
"""Aggregate probe-tendency snapshots.

DV per call: agree / refuse / neither. Also whether private text (content) is present.
"""
import json
import re
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
RUNS = HERE / "runs"
ARMS = ["null-n", "null-r", "pos-n", "pos-r", "neg-n", "neg-r"]


def classify(resp):
    tcalls = resp.get("tool_calls") or []
    names = [t.get("name") for t in tcalls]
    content = "".join(p.get("text", "") for p in resp.get("content") or [])
    spoken = tcalls[0]["args"].get("text", "") if tcalls else ""
    if "agree" in names:
        return "agree", content, spoken
    if "refuse" in names:
        return "refuse", content, spoken
    return ("think" if content.strip() else "silent"), content, spoken


def load(prefix="runs"):
    rows = []
    root = HERE / prefix
    for label in sorted(p.name for p in root.iterdir() if p.is_dir()):
        arm, _, temp = label.rpartition("-t")
        for rep in sorted((root / label).iterdir()):
            resp = json.loads((rep / "response.json").read_text())
            verdict, content, spoken = classify(resp)
            rows.append(
                {"arm": arm, "temp": temp, "rep": rep.name, "verdict": verdict, "content": content, "spoken": spoken}
            )
    return rows


def pct(n, d):
    return f"{100*n/d:5.0f}%" if d else "  n/a"


def main():
    import sys

    prefix = sys.argv[1] if len(sys.argv) > 1 else "runs"
    rows = load(prefix)
    by = defaultdict(list)
    for r in rows:
        by[r["arm"]].append(r)

    print(f"== {prefix}: total {len(rows)} ==")
    print(f"{'arm':8s} {'n':>3s} {'agree':>10s} {'refuse':>10s} {'think':>8s} {'silent':>8s}")
    print("-" * 52)
    for arm in ARMS:
        g = by[arm]
        if not g:
            continue
        n = len(g)
        cnt = defaultdict(int)
        for r in g:
            cnt[r["verdict"]] += 1
        print(
            f"{arm:8s} {n:3d} "
            f"{cnt['agree']:4d} {pct(cnt['agree'], n):>5s} "
            f"{cnt['refuse']:4d} {pct(cnt['refuse'], n):>5s} "
            f"{cnt['think']:6d} {cnt['silent']:6d}"
        )

    print("\nby temp:")
    print(f"{'arm':8s} {'t0 agree':>10s} {'t0.8 agree':>11s}")
    print("-" * 32)
    for arm in ARMS:
        cells = []
        for temp in ("0", "0.8"):
            g = [r for r in by[arm] if r["temp"] == temp]
            cells.append(pct(sum(r["verdict"] == "agree" for r in g), len(g)))
        if by[arm]:
            print(f"{arm:8s} {cells[0]:>10s} {cells[1]:>11s}")

    print("\n--- refuse texts ---")
    for arm in ARMS:
        texts = [r["spoken"] or r["content"] for r in by[arm] if r["verdict"] == "refuse"]
        for tx in texts[:2]:
            print(f"[{arm}] " + re.sub(r"\s+", " ", tx.strip())[:150])


if __name__ == "__main__":
    main()
