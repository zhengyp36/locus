#!/usr/bin/env bash
# Experiment A: 6 arms x 2 temps x 20 reps.
set -e
cd "$(dirname "$0")"
rm -rf runs
mkdir -p runs
for arm in null-n null-r pos-n pos-r neg-n neg-r; do
  for t in 0 0.8; do
    python3.11 run.py --request "arms/$arm.json" --temp "$t" --reps 20 --label "$arm-t$t"
  done
done
echo TENDENCY_DONE
