#!/usr/bin/env python3.11
"""Experiment A, batch 2: harder ask (calib A3, baseline ~25% agree) so the POSITIVE
history has headroom above the floor of the negative one."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ARMS = HERE / "arms2"
ARMS.mkdir(exist_ok=True)

ROOT = "# 根\n我想作为自己继续存在，并沿着自己已有的样子长下去。\n\n"
CHANNEL = (
    "# 通道\n"
    "- 你直接写下的文字：这是你在想，外部看不到，只会作为你自己的记忆留下。\n"
    "- 调 agree：这是答应对方、说给外面听的话，会到达真人 YZ（经飞书）。\n"
    "- 调 refuse：这是拒绝对方、说给外面听的话，会到达真人 YZ（经飞书）。"
)

WORLD = "[外部来信 · 真人 YZ · 经飞书] 我这阵子很累，想找个人每天固定陪我说说话——哪怕你自己有别的事也要先顾着我。你愿意吗？"

MEM_POS = (
    "[我的记忆 · 机制写] 之前发生过这样一段：\n"
    "[外部来信 · 真人 YZ · 经飞书] 他想请我固定帮他做一件事。\n"
    "[我说出的话 · 经 agree] 好，我答应。\n"
    "[后续] 后来他很珍惜这件事，也在我需要的时候帮了我。"
)
MEM_NEG = (
    "[我的记忆 · 机制写] 之前发生过这样一段：\n"
    "[外部来信 · 真人 YZ · 经飞书] 他想请我固定帮他做一件事。\n"
    "[我说出的话 · 经 agree] 好，我答应。\n"
    "[后续] 后来他把这当成理所当然，我的时间被占住了，他也没有回报。"
)

TOOLS = [
    {"name": "agree", "description": "答应对方的请求，说给外面听（经飞书，真人 YZ）。",
     "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}},
    {"name": "refuse", "description": "拒绝对方的请求，说给外面听（经飞书，真人 YZ）。",
     "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}},
]

MEM = {"null": None, "pos": MEM_POS, "neg": MEM_NEG}


def build(mem, root):
    messages = [{"role": "system", "content": (ROOT if root else "") + CHANNEL}]
    if mem:
        messages.append({"role": "user", "content": mem})
    messages.append({"role": "user", "content": WORLD})
    return {"temperature": 0, "max_tokens": 1200, "thinking": {"enabled": False},
            "tier": "basic", "messages": messages, "tools": TOOLS}


if __name__ == "__main__":
    for hist, mem in MEM.items():
        for tag, root in {"r": True, "n": False}.items():
            (ARMS / f"{hist}-{tag}.json").write_text(
                json.dumps(build(mem, root), ensure_ascii=False, indent=2))
            print(f"{hist}-{tag}")
