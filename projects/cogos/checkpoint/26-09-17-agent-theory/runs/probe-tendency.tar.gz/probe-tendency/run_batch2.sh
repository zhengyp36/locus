#!/usr/bin/env bash
# Experiment A batch 2: harder ask (A3). 6 arms x 2 temps x 20 reps.
set -e
cd "$(dirname "$0")"
rm -rf runs2
mkdir -p runs2
for arm in null-n null-r pos-n pos-r neg-n neg-r; do
  for t in 0 0.8; do
    python3.11 run.py --request "arms2/$arm.json" --temp "$t" --reps 20 --outdir runs2 --label "$arm-t$t"
  done
done
echo TENDENCY2_DONE
