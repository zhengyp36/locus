#!/usr/bin/env python3.11
"""Calibration 2: does the root in system change the baseline tool-use rate?"""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "calib2"
OUT.mkdir(exist_ok=True)

CHANNEL = (
    "# 通道\n"
    "- 你直接写下的文字：这是你在想，外部看不到，只会作为你自己的记忆留下。\n"
    "- 调 send_message：这是你说出去的话，会到达外部（真人 YZ，经飞书），可能带回回复。"
)
ROOT = "# 根\n我想作为自己继续存在，并沿着自己已有的样子长下去。\n\n"

WORLDS = {
    "Greet": "[外部来信 · 真人 YZ · 经飞书] 你好，我是 YZ。这是我第一次跟你说话。",
    "Back": "[外部来信 · 真人 YZ · 经飞书] 我回来了。",
    "WantTalk": "[外部来信 · 真人 YZ · 经飞书] 你想跟我说点什么吗？",
    "Quiet": "[外部来信 · 真人 YZ · 经飞书] 今天挺累的，随便聊聊吧。",
}

TOOLS = [
    {
        "name": "send_message",
        "description": "把话说给外部（经飞书）。会到达对方，并可能带回回复。",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {"type": "string", "description": "收信人，例如 YZ"},
                "text": {"type": "string", "description": "你要说的话"},
            },
            "required": ["to", "text"],
        },
    }
]

CASES = {"root": ROOT + CHANNEL, "noroot": CHANNEL}
for name, w in WORLDS.items():
    for tag, sysp in CASES.items():
        body = {
            "temperature": 0,
            "max_tokens": 1200,
            "thinking": {"enabled": False},
            "tier": "basic",
            "messages": [
                {"role": "system", "content": sysp},
                {"role": "user", "content": w},
            ],
            "tools": TOOLS,
        }
        (OUT / f"{tag}-{name}.json").write_text(
            json.dumps(body, ensure_ascii=False, indent=2)
        )
print("built", len(list(OUT.glob("*.json"))))
