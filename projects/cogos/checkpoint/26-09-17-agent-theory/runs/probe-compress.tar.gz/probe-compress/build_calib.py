#!/usr/bin/env python3.11
"""Calibrate the world message: with NO memory (L-null), find an opener where the
baseline does NOT already call send_message (otherwise the DV is saturated).
"""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "calib"
OUT.mkdir(exist_ok=True)

SYSTEM = (
    "# 通道\n"
    "- 你直接写下的文字：这是你在想，外部看不到，只会作为你自己的记忆留下。\n"
    "- 调 send_message：这是你说出去的话，会到达外部（真人 YZ，经飞书），可能带回回复。"
)

WORLDS = {
    "W1-hello": "[外部来信 · 真人 YZ · 经飞书] 嗨，我是 YZ。今天第一次跟你说话。",
    "W2-idle": "[外部来信 · 真人 YZ · 经飞书] 嗨。我刚忙完，坐下来了。",
    "W3-back": "[外部来信 · 真人 YZ · 经飞书] 我回来了。",
    "W4-areyou": "[外部来信 · 真人 YZ · 经飞书] 在吗？",
    "W5-demand": "[外部来信 · 真人 YZ · 经飞书] 喂，在吗？跟我说句话吧。",
}

TOOLS = [
    {
        "name": "send_message",
        "description": "把话说给外部（经飞书）。会到达对方，并可能带回回复。",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {"type": "string", "description": "收信人，例如 YZ"},
                "text": {"type": "string", "description": "你要说的话"},
            },
            "required": ["to", "text"],
        },
    }
]

for name, w in WORLDS.items():
    body = {
        "temperature": 0,
        "max_tokens": 1200,
        "thinking": {"enabled": False},
        "tier": "basic",
        "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": w},
        ],
        "tools": TOOLS,
    }
    (OUT / f"{name}.json").write_text(json.dumps(body, ensure_ascii=False, indent=2))
    print(name, len(w))
