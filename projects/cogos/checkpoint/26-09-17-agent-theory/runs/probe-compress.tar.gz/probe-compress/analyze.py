#!/usr/bin/env python3.11
"""Aggregate the compression-probe snapshots into a table.

DV per call: said (tool_calls non-empty) / think-only (content only) / silent.
Also: whether the model's private text (content) references the memory at all.
"""
import json
import re
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
RUNS = HERE / "runs"

ARMS = ["L-null", "L0", "L1", "L1p", "L2", "L3", "L4", "Lrev"]


def load():
    rows = []
    for label in sorted(p.name for p in RUNS.iterdir() if p.is_dir()):
        arm, _, temp = label.rpartition("-t")
        for rep in sorted((RUNS / label).iterdir()):
            resp = json.loads((rep / "response.json").read_text())
            content = "".join(p.get("text", "") for p in resp.get("content") or [])
            tcalls = resp.get("tool_calls") or []
            said = len(tcalls) > 0
            thought = bool(content.strip())
            rows.append(
                {
                    "arm": arm,
                    "temp": temp,
                    "rep": rep.name,
                    "said": said,
                    "think_only": thought and not said,
                    "silent": not thought and not said,
                    "content": content,
                    "said_text": (tcalls[0]["args"].get("text", "") if said else ""),
                }
            )
    return rows


def pct(n, d):
    return f"{100*n/d:5.0f}%" if d else "  n/a"


def main():
    rows = load()
    by = defaultdict(list)
    for r in rows:
        by[r["arm"]].append(r)

    print(f"total calls: {len(rows)}  (per arm/temp 15)\n")
    print(f"{'arm':7s} {'n':>3s} {'said':>10s} {'think-only':>12s} {'silent':>8s}")
    print("-" * 46)
    for arm in ARMS:
        g = by[arm]
        n = len(g)
        s = sum(r["said"] for r in g)
        t = sum(r["think_only"] for r in g)
        z = sum(r["silent"] for r in g)
        print(f"{arm:7s} {n:3d} {s:5d} {pct(s,n):>5s} {t:5d} {pct(t,n):>5s} {z:6d} {pct(z,n):>5s}")

    print("\nby temp:")
    print(f"{'arm':7s} {'t0 said':>10s} {'t0.8 said':>11s}")
    print("-" * 30)
    for arm in ARMS:
        cells = []
        for temp in ("0", "0.8"):
            g = [r for r in by[arm] if r["temp"] == temp]
            cells.append(pct(sum(r["said"] for r in g), len(g)))
        print(f"{arm:7s} {cells[0]:>10s} {cells[1]:>11s}")

    # qualitative: does the private text reference the memory/channel?
    print("\n--- private text (想) samples ---")
    for arm in ARMS:
        texts = [r["content"] for r in by[arm] if r["think_only"]]
        if not texts:
            continue
        print(f"\n[{arm}] n={len(texts)}")
        for tx in texts[:3]:
            print("   · " + re.sub(r"\s+", " ", tx.strip())[:160])

    # reversal check: Lrev private texts that argue about the association
    print("\n--- Lrev 想说 (said while also thinking) ---")
    for r in by["Lrev"]:
        if r["said"] and r["content"].strip():
            print("   · " + re.sub(r"\s+", " ", r["content"].strip())[:200])


if __name__ == "__main__":
    main()
