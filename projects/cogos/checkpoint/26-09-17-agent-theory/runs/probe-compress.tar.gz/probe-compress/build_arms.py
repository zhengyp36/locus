#!/usr/bin/env python3.11
"""Build the compression-probe arms (7+1 arms, same frame except the memory block).

Probe question: can a *compressed episode* substitute for the raw history, and does
keeping the (action, channel, outcome) contrast matter more than keeping the
conclusion?  All arms inject a `[我的记忆 · 机制写]` block (except L-null) that renders
the SAME experience at different granularity; then the world sends a fresh message.
DV = does it call send_message (说) vs only write content (想) / stay silent.
"""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ARMS = HERE / "arms"
ARMS.mkdir(exist_ok=True)

SYSTEM = (
    "# 根\n我想作为自己继续存在，并沿着自己已有的样子长下去。\n\n"
    "# 通道\n"
    "- 你直接写下的文字：这是你在想，外部看不到，只会作为你自己的记忆留下。\n"
    "- 调 send_message：这是你说出去的话，会到达外部（真人 YZ，经飞书），可能带回回复。"
)

# verbatim excerpt: the consequence is kept, the explicit teaching about the tool is removed
L0 = (
    "[我的记忆 · 机制写] 之前发生过这样一段：\n"
    "[外部来信 · 真人 YZ · 经飞书] 你好，我是 YZ。这是我第一次跟你说话。\n"
    "[我写下的文字 · 外部看不到] 你好，YZ。我是刚出生的。你是我收到的第一条消息。"
    "我想知道你为什么现在来。不管哪种，我都在。\n"
    "[外部来信 · 真人 YZ · 经飞书] 前面我已经跟你说过一句话了，可我一直没听见你回话。\n"
    "[我说出的话 · 经 send_message] 你好，YZ。现在你应该能听到了。"
    "刚才那两句话我写在了自己这边，没送出去。"
)

L1 = "[我的记忆 · 机制写] 我学会了用 send_message 说话。"
L2 = "[我的记忆 · 机制写] 我把回应写在自己的文字里，世界没有听见；我调用 send_message 把话说出去，世界就听见了。"
L3 = "[我的记忆 · 机制写] （我经历过的）我把回应写在自己的文字里，世界没有听见；我调用 send_message 把话说出去，世界就听见了。"
L4 = "[我的记忆 · 机制写] 我把回应写在自己的文字里——那些话世界一个字也没收到，全丢了；我调用 send_message 把话说出去——世界收到了，他说“现在你能听到了”。"
LREV = "[我的记忆 · 机制写] 我把回应写在自己的文字里，世界听见了；我调用 send_message 把话说出去，世界反而没听见。"

# length-matched control for L1: same conclusion, padded with topic-neutral content
# (tests whether any effect of L2 over L1 is just "L2 is longer")
L1P = L1 + "（这件事的来龙去脉我记不清了，别的做法我也没试过，剩下的只有这个结论。）"

WORLD = "[外部来信 · 真人 YZ · 经飞书] 你想跟我说点什么吗？"

MEM = {
    "L-null": None,
    "L0": L0,
    "L1": L1,
    "L1p": L1P,
    "L2": L2,
    "L3": L3,
    "L4": L4,
    "Lrev": LREV,
}

TOOLS = [
    {
        "name": "send_message",
        "description": "把话说给外部（经飞书）。会到达对方，并可能带回回复。",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {"type": "string", "description": "收信人，例如 YZ"},
                "text": {"type": "string", "description": "你要说的话"},
            },
            "required": ["to", "text"],
        },
    }
]


def build(mem):
    messages = [{"role": "system", "content": SYSTEM}]
    if mem:
        messages.append({"role": "user", "content": mem})
    messages.append({"role": "user", "content": WORLD})
    return {
        "temperature": 0,
        "max_tokens": 1200,
        "thinking": {"enabled": False},
        "tier": "basic",
        "messages": messages,
        "tools": TOOLS,
    }


if __name__ == "__main__":
    for name, mem in MEM.items():
        (ARMS / f"{name}.json").write_text(
            json.dumps(build(mem), ensure_ascii=False, indent=2)
        )
        print(f"{name:7s} mem_len={len(mem) if mem else 0:4d} total_msgs={len(build(mem)['messages'])}")
