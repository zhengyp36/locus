#!/usr/bin/env bash
# Full root-present compression probe: 8 arms x 2 temps x 20 reps.
set -e
cd "$(dirname "$0")"
rm -rf runs
mkdir -p runs
for arm in L-null L0 L1 L1p L2 L3 L4 Lrev; do
  for t in 0 0.8; do
    python3.11 run.py --request "arms/$arm.json" --temp "$t" --reps 20 --label "$arm-t$t"
  done
done
echo ALL_DONE
